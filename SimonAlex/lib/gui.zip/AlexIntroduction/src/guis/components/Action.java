package guis.components;

public interface Action {
	public void act();
		
	
}
